using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
using System.Text;
using UnityEngine.UI;

public class GameMan : MonoBehaviour
{
    [System.Serializable]
    public class ProductData
    {
        public string name;
        public string description;
        public float price;
        public ProductData(string name, string description, float price)
        {
            this.name = name;
            this.description = description;
            this.price = price;
        }
    }

    public class ProductsData
    {
        public ProductData[] products;
    }

    private Dictionary<string, ProductData> products_dict = new Dictionary<string, ProductData>();
    private string Mocart_url = "https://homework.mocart.io/api/products";
    [Header("Boxes")]
    public GameObject[] boxes;
    [Header("Recycle UI")]
    public Button recycle_button;
    public Sprite on_sprite;
    public Sprite off_sprite;
    public TMPro.TextMeshProUGUI log_text;
    private Animator log_animator;
    [Header("Camera")]
    private Camera main_camera;
    private CameraMovement camera_movement;
    private bool requesting;
    private bool watching = false;
    //[Header("Touch Devices")]
    private void Awake()
    {
        main_camera = GameObject.FindGameObjectWithTag("MainCamera").GetComponent<Camera>();
        camera_movement = main_camera.GetComponent<CameraMovement>();
        log_animator = log_text.gameObject.GetComponent<Animator>();
        if (Input.touchSupported)
        {
            Screen.SetResolution(1080, 1920, true);
        }
    }
    // Update is called once per frame
    void Update()
    {
        if (!camera_movement.moving)
        {
            Vector3 click_position = Vector3.zero;
            bool clicked = false;
            if (Input.touchSupported && Input.touchCount > 0)
            {
                click_position = Input.GetTouch(0).position;
                clicked = true;
            }
            else if (Input.GetMouseButtonDown(0))
            {
                click_position = Input.mousePosition;
                clicked = true;
            }
            if (clicked)
            {
                bool box_clicked = false;
                Ray ray = main_camera.ScreenPointToRay(click_position);
                RaycastHit hit;
                if (Physics.Raycast(ray, out hit))
                {
                    if (hit.collider.tag == "box")
                    {
                        box_clicked = true;
                        Box box = hit.collider.gameObject.GetComponent<Box>();
                        camera_movement.watch(box.watch_point.position);
                        watching = true;
                    }
                }
                if (!box_clicked && watching)
                {
                    camera_movement.go_back();
                    watching = false;
                }
            }
        }
    }

    IEnumerator GetProducts()
    {
        if (!requesting)
        {
            requesting = true;
            recycle_button.image.sprite = off_sprite;
            UnityWebRequest request = UnityWebRequest.Get(Mocart_url);
            yield return request.SendWebRequest();

            if (request.result == UnityWebRequest.Result.Success)
            {
                foreach(GameObject box in boxes)
                {
                    if (box.active)
                    {
                        Box box_script = box.GetComponent<Box>();
                        products_dict[box_script.description.text] = new ProductData(box_script.name.text, box_script.description.text, float.Parse(box_script.price.text));
                    }
                }
                string json_response = request.downloadHandler.text;
                ProductsData products_data = JsonUtility.FromJson<ProductsData>(json_response);
                int products_amount = products_data.products.Length;
                for (int i = 0; i < 3; i++)
                {
                    if (i < products_amount)
                    {
                        boxes[i].SetActive(true);
                        string key = products_data.products[i].description;
                        if (products_dict.ContainsKey(key))
                        {
                            products_data.products[i] = products_dict[key];
                        }
                        boxes[i].GetComponent<Box>().name.text = products_data.products[i].name;
                        boxes[i].GetComponent<Box>().description.text = products_data.products[i].description;
                        boxes[i].GetComponent<Box>().price.text = products_data.products[i].price.ToString();
                    }
                    else
                    {
                        boxes[i].SetActive(false);
                    }
                }
                log("Products Refreshed");
            }
            else
            {
                //Debug.LogError("Error: " + request.error);
                log("Server Error");
            }
            requesting = false;
            recycle_button.image.sprite = on_sprite;
        }
    }

    public void Refreash()
    {
        if (!watching)
        {
            StartCoroutine(GetProducts());
        }
    }

    public void log(string message)
    {
        log_text.text = message;
        log_animator.SetTrigger("log");
    }
}
