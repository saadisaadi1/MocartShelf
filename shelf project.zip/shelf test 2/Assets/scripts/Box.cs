using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class Box : MonoBehaviour
{
    public InputField name;
    public TMPro.TextMeshProUGUI description;
    public InputField price;
    public Transform watch_point;
}
