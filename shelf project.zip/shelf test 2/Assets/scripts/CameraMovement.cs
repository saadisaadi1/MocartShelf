using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class CameraMovement : MonoBehaviour
{
    Vector3 starting_position;
    public float move_duration;
    [HideInInspector] public bool moving = false;
    // Start is called before the first frame update
    void Start()
    {
        starting_position = transform.position;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void watch(Vector3 watch_position)
    {
        StartCoroutine(move(watch_position));
    }
    public void go_back()
    {
        StartCoroutine(move(starting_position));
    }
    IEnumerator move(Vector3 target)
    {
        moving = true;
        Vector3 start = transform.position;
        float timer = 0;
        while(timer < move_duration)
        {
            timer += Time.deltaTime;
            transform.position = start + (target - start) * Mathf.InverseLerp(0, move_duration, timer);
            yield return null;
        }
        yield return null;
        moving = false;
    }
}
